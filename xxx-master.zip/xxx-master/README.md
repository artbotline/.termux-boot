SELFBOT By:™ചচ✾ъπ່७✾ざণاعနัю❍ีざန

------❍ণហ ざণاعနัю❍ีざန------

pkg install git -y

pkg install nano -y

pkg install python2 -y

pkg install pip2

pip2 install request

pip2 install rsa

pip2 install thrift==0.9.3

pip2 install pyowm

pip2 install tweepy

pip2 install html5

pip2 install BeautifulSoup4

pip2 install BeautifulSoup

pip2 install wikipedia

pip2 install goslate

pip2 install gtts

pip2 install googletrans

pip2 install Translator

git clone https://github.com/artbotline/art.git

----------------------

ls

cd art

ls

nano ___.py

python2 ___.py

----------------------
